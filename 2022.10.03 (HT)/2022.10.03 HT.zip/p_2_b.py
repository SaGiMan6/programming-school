for i in range(5, 0, -1):

    for j in range(i):
        print(1, end=" ")

    print()
